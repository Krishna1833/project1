package com.example.onlineClinicSystem.controller;

import org.springframework.stereotype.Controller;

public class PatientSignup {
	@Controller
	public class DocterController{

		
		public String home() {
			return "PatientSignup";
		}
	}
	

}
