package com.example.onlineClinicSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineClinicSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineClinicSystem1Application.class, args);
	}

}
