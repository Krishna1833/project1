package com.example.onlineClinicSystem.entity;

public class Doctor extends UserDetail {
	private String  specialization;
	private String department;

}
