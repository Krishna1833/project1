package com.example.onlineClinicSystem.entity;

public class Address {
	private String colony;
	private String city;
	private String state;
	private String pincode;
}
