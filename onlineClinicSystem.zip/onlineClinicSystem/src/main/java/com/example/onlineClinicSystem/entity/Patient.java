package com.example.onlineClinicSystem.entity;

public class Patient extends UserDetail {
	private String sympton;
	private String disease;
	private String duration;

}
